## Mini ChatGPT (Gemini API)

A minimal chat app (frontend + backend) powered by Google's Gemini API. The backend keeps your API key safe and exposes a simple `/api/chat` endpoint. The frontend provides a clean chat UI.

### Features
- Chat-style UI with message history
- Uses Gemini model (`gemini-1.5-flash` by default)
- Simple Node.js/Express backend proxy to avoid exposing your API key

### Prerequisites
- Node.js 18+ and npm
- A Gemini API key from Google AI Studio (`https://aistudio.google.com`)

### Setup
1. Open a terminal in the project folder.
2. Install server dependencies and configure your API key:
   - `cd server`
   - `npm install`
   - Copy `.env.example` to `.env` and set your key:
     - On Windows PowerShell: `Copy-Item .env.example .env`
     - Then edit `.env` and set `GEMINI_API_KEY=AIzaSyDo5Yb2dioMi3OyBHWJoXyFNcVqa_Kt1ng`
3. Start the server:
   - Development (auto-reload): `npm run dev`
   - Or production: `npm start`
4. Open `http://localhost:3004` in your browser.

### Environment Variables
- `GEMINI_API_KEY` (required): Your Gemini API key.
- `PORT` (optional): Server port (defaults to `3004`).

### File Structure
- `server/`: Express backend using `@google/generative-ai`
- `client/`: Static frontend (HTML/CSS/JS)

### Notes
- The frontend maintains chat history in the browser and sends it with each request.
- System messages (if any) are merged into the first user message as an instruction for Gemini.
- To change the model, update the `DEFAULT_MODEL` in `server/src/index.js` and the `MODEL_NAME` in `client/main.js` (optional; backend already enforces its default).




