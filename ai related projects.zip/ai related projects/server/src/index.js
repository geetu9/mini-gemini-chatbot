import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenerativeAI } from '@google/generative-ai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? Number(process.env.PORT) : 3004;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const DEFAULT_MODEL = 'gemini-2.0-flash-exp';

if (!GEMINI_API_KEY) {
  console.warn('[WARN] GEMINI_API_KEY is not set. /api/chat requests will fail until it is configured.');
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(morgan('dev'));

const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, model: DEFAULT_MODEL });
});

function validateMessages(messages) {
  if (!Array.isArray(messages) || !messages.length) return 'messages must be a non-empty array.';
  for (const m of messages) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') {
      return 'Each message must have role "user" | "assistant" and string content.';
    }
  }
  return null;
}

function toGeminiContents(messages, attachments) {
  const contents = messages.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  if (attachments && Array.isArray(attachments) && attachments.length) {
    let idx = contents.length - 1;
    if (idx < 0 || contents[idx].role !== 'user') {
      contents.push({ role: 'user', parts: [] });
      idx = contents.length - 1;
    }
    for (const att of attachments) {
      if (!att || !att.mimeType || !att.dataBase64) continue;
      contents[idx].parts.push({ inlineData: { mimeType: att.mimeType, data: att.dataBase64 } });
    }
  }

  return contents;
}

app.post('/api/chat', async (req, res) => {
  try {
    if (!GEMINI_API_KEY) return res.status(500).json({ error: 'Server not configured. Missing GEMINI_API_KEY.' });

    const { messages, model, temperature, maxOutputTokens, system, attachments } = req.body || {};
    const err = validateMessages(messages);
    if (err) return res.status(400).json({ error: err });

    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const modelOptions = { model: typeof model === 'string' && model.trim() ? model.trim() : DEFAULT_MODEL };
    if (system && typeof system === 'string' && system.trim()) {
      modelOptions.systemInstruction = { role: 'system', parts: [{ text: system.trim() }] };
    }
    const generativeModel = genAI.getGenerativeModel(modelOptions);

    const generationConfig = {};
    if (typeof temperature === 'number') generationConfig.temperature = temperature;
    if (typeof maxOutputTokens === 'number') generationConfig.maxOutputTokens = maxOutputTokens;

    const result = await generativeModel.generateContent({
      contents: toGeminiContents(messages, attachments),
      generationConfig,
    });
    const text = result?.response?.text?.() ?? '';
    res.json({ reply: text });
  } catch (e) {
    console.error('Chat error:', e);
    res.status(500).json({ error: e?.message || 'Unknown error' });
  }
});

// Streaming endpoint (chunked text)
app.post('/api/chat/stream', async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      res.status(500).end('Missing GEMINI_API_KEY');
      return;
    }
    const { messages, model, temperature, maxOutputTokens, system, attachments } = req.body || {};
    const err = validateMessages(messages);
    if (err) {
      res.status(400).end(err);
      return;
    }

    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const modelOptions = { model: typeof model === 'string' && model.trim() ? model.trim() : DEFAULT_MODEL };
    if (system && typeof system === 'string' && system.trim()) {
      modelOptions.systemInstruction = { role: 'system', parts: [{ text: system.trim() }] };
    }
    const generativeModel = genAI.getGenerativeModel(modelOptions);

    const generationConfig = {};
    if (typeof temperature === 'number') generationConfig.temperature = temperature;
    if (typeof maxOutputTokens === 'number') generationConfig.maxOutputTokens = maxOutputTokens;

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');

    const result = await generativeModel.generateContentStream({
      contents: toGeminiContents(messages, attachments),
      generationConfig,
    });

    for await (const chunk of result.stream) {
      const t = chunk?.text();
      if (t) res.write(t);
    }
    res.end();
  } catch (e) {
    console.error('Stream error:', e);
    try { res.end(); } catch {}
  }
});

// Fallback to index.html
app.get('*', (_req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
