const messagesContainer = document.getElementById('messages');
const form = document.getElementById('chat-form');
const input = document.getElementById('input');
const sendButton = document.getElementById('send');
const clearButton = document.getElementById('clear');
const newChatButton = document.getElementById('new-chat');
const sessionsEl = document.getElementById('sessions');
const micButton = document.getElementById('mic-btn');
const typing = document.getElementById('typing');
const statusEl = document.getElementById('app-status');
const attachBtn = document.getElementById('attach-btn');
const fileInput = document.getElementById('files');
const attachmentsEl = document.getElementById('attachments');
const shareChatBtn = document.getElementById('share-chat');
const autoSpeakToggle = document.getElementById('auto-speak');
const langSelect = document.getElementById('lang-select');
const ttsTestBtn = document.getElementById('tts-test');

const API_BASE = '';
const MODEL_NAME = 'gemini-2.0-flash-exp';

const SESSIONS_KEY = 'mini-gemini-sessions';
const ACTIVE_ID_KEY = 'mini-gemini-active-session-id';
const LEGACY_KEY = 'mini-gemini-history';

let sessions = [];
let activeId = null;
let recognition = null, recognizing = false;
let pendingFiles = [];
let currentUtterance = null;
let audioUnlocked = false;

// Map app language preference to BCP-47 locale for speech APIs
function mapLangPrefToLocale(pref) {
  try {
    const lang = (pref || localStorage.getItem('mini-gemini-lang') || 'auto');
    if (!lang || lang === 'auto') return (navigator.language || 'en-US');
    switch (lang) {
      case 'en': return 'en-US';
      case 'hi': return 'hi-IN';
      case 'te': return 'te-IN';
      case 'ta': return 'ta-IN';
      case 'bn': return 'bn-IN';
      case 'mr': return 'mr-IN';
      case 'kn': return 'kn-IN';
      case 'ml': return 'ml-IN';
      case 'gu': return 'gu-IN';
      case 'pa': return 'pa-IN';
      case 'ur': return 'ur-IN';
      case 'es': return 'es-ES';
      case 'fr': return 'fr-FR';
      case 'de': return 'de-DE';
      case 'ar': return 'ar-SA';
      case 'zh': return 'zh-CN';
      case 'ja': return 'ja-JP';
      case 'ko': return 'ko-KR';
      default: return lang;
    }
  } catch { return (navigator.language || 'en-US'); }
}

function el(tag, className, text) { const e = document.createElement(tag); if (className) e.className = className; if (text != null) e.textContent = text; return e; }
function nowISO() { return new Date().toISOString(); }
function shortTime(iso) { try { return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return ''; } }

function setStatus(text, ok = true) { if (!statusEl) return; statusEl.textContent = text; statusEl.style.color = ok ? 'var(--muted)' : '#ff6b6b'; }
async function pingHealth() { try { const r = await fetch('/api/health'); const j = await r.json(); setStatus(`Online • ${j.model}`, true); } catch { setStatus('Offline', false); } }

function loadSessions() { try { const j = JSON.parse(localStorage.getItem(SESSIONS_KEY) || '[]'); return Array.isArray(j) ? j : []; } catch { return []; } }
function saveSessions() { try { localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions)); } catch {} }
function loadActiveId() { try { return localStorage.getItem(ACTIVE_ID_KEY); } catch { return null; } }
function saveActiveId(id) { try { localStorage.setItem(ACTIVE_ID_KEY, id || ''); } catch {} }

function migrateLegacy() {
  try {
    const raw = localStorage.getItem(LEGACY_KEY);
    if (!raw) return;
    const msgs = JSON.parse(raw);
    if (Array.isArray(msgs) && msgs.length) {
      const id = 's_' + Date.now();
      sessions.push({ id, title: 'Imported chat', messages: msgs, updatedAt: nowISO() });
      saveSessions(); saveActiveId(id);
      localStorage.removeItem(LEGACY_KEY);
    }
  } catch {}
}

// Persistent lightweight memory (local to this browser)
const MEMORY_KEY = 'mini-gemini-memory';

function loadMemory() {
  try { return JSON.parse(localStorage.getItem(MEMORY_KEY) || '{}'); } catch { return {}; }
}
function saveMemory(mem) {
  try { localStorage.setItem(MEMORY_KEY, JSON.stringify(mem || {})); } catch {}
}
function buildSystemFromMemory() {
  const m = loadMemory();
  const parts = [];
  if (m.name) parts.push(`The user's name is ${m.name}. Always greet them by name.`);
  try {
    const pref = localStorage.getItem('mini-gemini-lang') || 'auto';
    if (pref && pref !== 'auto') parts.push(`Respond in ${pref} language.`);
  } catch {}
  return parts.join(' ');
}
function updateMemoryFromText(text) {
  if (!text) return;
  const m = text.match(/\bmy name is\s+([A-Za-z][A-Za-z\s'-]{0,40})\.?$/i);
  if (m) {
    const name = m[1].trim();
    const mem = loadMemory();
    mem.name = name;
    saveMemory(mem);
  }
}

function createSession(title = 'New chat') {
  const id = 's_' + Date.now();
  const s = { id, title, messages: [], updatedAt: nowISO() };
  sessions.unshift(s);
  saveSessions(); saveActiveId(id);
  return s;
}

function getActive() { return sessions.find(s => s.id === activeId) || null; }

function renderSessions() {
  if (!sessionsEl) return;
  sessionsEl.innerHTML = '';
  sessions.forEach(s => {
    const item = el('div', 'session-item' + (s.id === activeId ? ' active' : ''));
    const title = el('div', 'session-title', s.title || 'Untitled');
    const time = el('div', 'session-time', shortTime(s.updatedAt));
    const kebab = el('button', 'kebab', '⋯');
    const menu = el('div', 'menu hidden');
    const renameBtn = el('button', 'menu-item', 'Rename'); renameBtn.dataset.action = 'rename';
    const deleteBtn = el('button', 'menu-item danger', 'Delete'); deleteBtn.dataset.action = 'delete';
    menu.appendChild(renameBtn); menu.appendChild(deleteBtn);

    item.appendChild(title); item.appendChild(time); item.appendChild(kebab); item.appendChild(menu);

    item.addEventListener('click', (ev) => {
      if (ev.target === kebab || menu.contains(ev.target)) return;
      activeId = s.id; saveActiveId(activeId); renderSessions(); renderChat();
    });

    kebab.addEventListener('click', (ev) => {
      ev.stopPropagation();
      document.querySelectorAll('.sessions .menu').forEach(m => m.classList.add('hidden'));
      menu.classList.toggle('hidden');
    });

    renameBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const name = prompt('Rename chat:', s.title || 'Untitled');
      if (!name) return;
      s.title = name.trim(); s.updatedAt = nowISO(); saveSessions(); renderSessions();
      menu.classList.add('hidden');
    });

    deleteBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      if (!confirm('Delete this chat?')) return;
      const idx = sessions.findIndex(x => x.id === s.id);
      if (idx >= 0) sessions.splice(idx, 1);
      if (!sessions.length) { const first = createSession('New chat'); activeId = first.id; }
      if (activeId === s.id) activeId = sessions[0].id;
      saveSessions(); saveActiveId(activeId); renderSessions(); renderChat();
    });

    sessionsEl.appendChild(item);
  });
}

function renderChat() {
  messagesContainer.innerHTML = '';
  const s = getActive();
  if (!s || !s.messages.length) { addHint(); return; }
  s.messages.forEach((m, idx) => renderMessage(m.role, m.content, idx));
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function renderMessage(role, content, index) {
  const row = el('div', 'msg');
  const avatar = el('div', `avatar ${role === 'user' ? 'user' : 'bot'}`, role === 'user' ? 'U' : 'G');
  const bubble = el('div', `bubble ${role}`); bubble.textContent = content;

  const kebab = el('button', 'kebab', '⋯');
  const menu = el('div', 'menu hidden');
  const copyBtn = el('button', 'menu-item', 'Copy'); copyBtn.dataset.action = 'copy';
  const editBtn = el('button', 'menu-item', 'Edit'); editBtn.dataset.action = 'edit';
  const shareBtn = el('button', 'menu-item', 'Share'); shareBtn.dataset.action = 'share';
  const delBtn = el('button', 'menu-item danger', 'Delete'); delBtn.dataset.action = 'delete';
  menu.appendChild(copyBtn); menu.appendChild(editBtn); menu.appendChild(shareBtn); menu.appendChild(delBtn);

  kebab.addEventListener('click', (ev) => {
    ev.stopPropagation();
    document.querySelectorAll('.messages .menu').forEach(m => m.classList.add('hidden'));
    menu.classList.toggle('hidden');
  });

  copyBtn.addEventListener('click', async (ev) => {
    ev.stopPropagation();
    try { await navigator.clipboard.writeText(content); } catch {}
    menu.classList.add('hidden');
  });

  editBtn.addEventListener('click', (ev) => {
    ev.stopPropagation();
    const s = getActive(); if (!s) return;
    const current = s.messages[index]?.content || '';
    const next = prompt('Edit message:', current);
    if (next == null) return;
    s.messages[index].content = String(next);
    s.updatedAt = nowISO(); saveSessions();
    renderChat();
    menu.classList.add('hidden');
  });

  shareBtn.addEventListener('click', async (ev) => {
    ev.stopPropagation();
    const textToShare = `${role.toUpperCase()}: ${content}`;
    try {
      if (navigator.share) {
        await navigator.share({ text: textToShare });
      } else {
        await navigator.clipboard.writeText(textToShare);
        alert('Message copied to clipboard. You can paste it to share.');
      }
    } catch {}
    menu.classList.add('hidden');
  });

  delBtn.addEventListener('click', (ev) => {
    ev.stopPropagation();
    if (!confirm('Delete this message?')) return;
    const s = getActive(); if (!s) return;
    s.messages.splice(index, 1);
    s.updatedAt = nowISO(); saveSessions();
    renderChat();
  });

  row.appendChild(avatar); row.appendChild(bubble); row.appendChild(kebab); row.appendChild(menu);
  messagesContainer.appendChild(row);

  // Assistant action bar below assistant messages
  if (role === 'assistant') {
    const bar = el('div', 'actions');
    const copyA = el('button', null, 'Copy');
    const shareA = el('button', null, 'Share');
    const useA = el('button', null, 'Use as prompt');
    const regenA = el('button', null, 'Regenerate');
    const speakA = el('button', null, 'Speak');
    const stopA = el('button', null, 'Stop');

    copyA.addEventListener('click', async () => { try { await navigator.clipboard.writeText(content); } catch {} });
    shareA.addEventListener('click', async () => {
      const text = content;
      try {
        if (navigator.share) await navigator.share({ text });
        else { await navigator.clipboard.writeText(text); alert('Copied. You can paste to share.'); }
      } catch {}
    });
    useA.addEventListener('click', () => {
      input.value = content;
      input.focus();
    });
    regenA.addEventListener('click', async () => {
      const s = getActive(); if (!s) return;
      // Remove the last assistant message and ask again using prior context
      if (s.messages[index] && s.messages[index].role === 'assistant') {
        s.messages.splice(index, 1); s.updatedAt = nowISO(); saveSessions(); renderSessions(); renderChat();
      }
      try {
        setSending(true);
        const system = buildSystemFromMemory();
        const { reply } = await sendChatReq(s.messages, system, []);
        s.messages.push({ role: 'assistant', content: reply }); s.updatedAt = nowISO(); saveSessions(); renderSessions();
        renderMessage('assistant', reply, s.messages.length - 1);
      } catch (err) {
        renderMessage('assistant', `Error: ${err?.message || 'Something went wrong'}`, s.messages.length);
      } finally {
        setSending(false);
      }
    });

    function mapLangToLocale(lang) {
      if (!lang || lang === 'auto') return (navigator.language || 'en-US');
      switch (lang) {
        case 'en': return 'en-US';
        case 'hi': return 'hi-IN';
        case 'te': return 'te-IN';
        case 'ta': return 'ta-IN';
        case 'bn': return 'bn-IN';
        case 'mr': return 'mr-IN';
        case 'kn': return 'kn-IN';
        case 'ml': return 'ml-IN';
        case 'gu': return 'gu-IN';
        case 'pa': return 'pa-IN';
        case 'ur': return 'ur-IN';
        case 'es': return 'es-ES';
        case 'fr': return 'fr-FR';
        case 'de': return 'de-DE';
        case 'ar': return 'ar-SA';
        case 'zh': return 'zh-CN';
        case 'ja': return 'ja-JP';
        case 'ko': return 'ko-KR';
        default: return lang;
      }
    }

    function getVoicesAsync() {
      try {
        const v = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
        if (v && v.length) return Promise.resolve(v);
        return new Promise((resolve) => {
          let resolved = false;
          const done = () => { if (!resolved) { resolved = true; resolve(window.speechSynthesis.getVoices() || []); } };
          if (!window.speechSynthesis) return resolve([]);
          window.speechSynthesis.onvoiceschanged = () => { done(); window.speechSynthesis.onvoiceschanged = null; };
          setTimeout(done, 800);
        });
      } catch { return Promise.resolve([]); }
    }

    function pickBestVoice(langTag, voices) {
      if (!voices || !voices.length) return null;
      const lower = (langTag || '').toLowerCase();
      const base = lower.split('-')[0];
      let match = voices.find(v => (v.lang || '').toLowerCase() === lower);
      if (match) return match;
      match = voices.find(v => (v.lang || '').toLowerCase().startsWith(base + '-'));
      if (match) return match;
      match = voices.find(v => (v.lang || '').toLowerCase().startsWith(base));
      if (match) return match;
      return voices[0] || null;
    }

    async function speakText(text) {
      try {
        if (!window.speechSynthesis) { setStatus('Speech not supported', false); return; }
        unlockAudioIfNeeded();
        if (currentUtterance) { try { window.speechSynthesis.cancel(); } catch {} currentUtterance = null; }
        const langTag = mapLangPrefToLocale();
        try { window.speechSynthesis.cancel(); window.speechSynthesis.resume(); } catch {}
        const u = new SpeechSynthesisUtterance(text);
        u.rate = 1; u.pitch = 1; u.lang = langTag;
        u.onend = () => { try { setStatus('Ready'); } catch {} };
        u.onerror = () => { try { setStatus('Speech error', false); } catch {} };
        const voices = await getVoicesAsync();
        const best = pickBestVoice(langTag, voices);
        if (best) u.voice = best;
        currentUtterance = u;
        setStatus('Speaking…');
        window.speechSynthesis.speak(u);
      } catch {}
    }

    function stopSpeech() {
      try { if (window.speechSynthesis) { window.speechSynthesis.cancel(); } currentUtterance = null; setStatus('Ready'); } catch {}
    }

    speakA.addEventListener('click', () => { try { speakText(content); } catch {} });
    stopA.addEventListener('click', stopSpeech);

    bar.appendChild(copyA);
    bar.appendChild(shareA);
    bar.appendChild(useA);
    bar.appendChild(regenA);
    bar.appendChild(speakA);
    bar.appendChild(stopA);
    messagesContainer.appendChild(bar);
  }
}

function setSending(sending) { sendButton.disabled = sending; input.disabled = sending; if (typing) typing.classList.toggle('hidden', !sending); }

async function sendChatReq(messages, system, attachments) {
  const resp = await fetch(`${API_BASE}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages, model: MODEL_NAME, temperature: 0.7, system: system || '', attachments: attachments || [] }) });
  if (!resp.ok) { let err = { error: resp.statusText }; try { err = await resp.json(); } catch {} throw new Error(err.error || 'Request failed'); }
  return resp.json();
}

function addHint() {
  const existing = document.querySelector('.hint'); if (existing) existing.remove();
  const hint = el('div', 'hint', 'Tip: Attach an image and ask “Describe this.”'); messagesContainer.parentElement.appendChild(hint);
}

function ensureActiveSession() {
  if (!sessions.length) { const first = createSession('New chat'); activeId = first.id; }
  if (!activeId || !sessions.some(s => s.id === activeId)) { activeId = sessions[0].id; saveActiveId(activeId); }
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = input.value.trim(); if (!text && pendingFiles.length === 0) return;
  input.value = '';

  // update profile memory if user provides name
  updateMemoryFromText(text);

  ensureActiveSession();
  const s = getActive();
  if (s.messages.length === 0 && text) s.title = text.split(/\s+/).slice(0, 6).join(' ');
  if (text) {
    s.messages.push({ role: 'user', content: text });
  } else if (!text && pendingFiles.length) {
    s.messages.push({ role: 'user', content: '(attached files)' });
  }
  s.updatedAt = nowISO(); saveSessions(); renderSessions();

  renderMessage('user', text || '(attached files)', s.messages.length - 1);

  try {
    setSending(true);
    const system = buildSystemFromMemory();
    const { reply } = await sendChatReq(s.messages, system, pendingFiles);
    s.messages.push({ role: 'assistant', content: reply }); s.updatedAt = nowISO(); saveSessions(); renderSessions();
    renderMessage('assistant', reply, s.messages.length - 1);
    // Auto-speak assistant replies if enabled
    try {
      const auto = localStorage.getItem('mini-gemini-auto-speak') === '1';
      if (auto && window.speechSynthesis) {
        const langTag = mapLangPrefToLocale();
        try { window.speechSynthesis.cancel(); window.speechSynthesis.resume(); } catch {}
        const u = new SpeechSynthesisUtterance(reply);
        u.rate = 1; u.pitch = 1; u.lang = langTag;
        try { setStatus('Speaking…'); } catch {}
        u.onend = () => { try { setStatus('Ready'); } catch {} };
        u.onerror = () => { try { setStatus('Speech error', false); } catch {} };
        const getVoicesAsync = () => {
          const v = window.speechSynthesis.getVoices();
          if (v && v.length) return Promise.resolve(v);
          return new Promise((resolve) => {
            let resolved = false;
            const done = () => { if (!resolved) { resolved = true; resolve(window.speechSynthesis.getVoices() || []); } };
            window.speechSynthesis.onvoiceschanged = () => { done(); window.speechSynthesis.onvoiceschanged = null; };
            setTimeout(done, 800);
          });
        };
        const pickBestVoice = (tag, voices) => {
          if (!voices || !voices.length) return null; const lower = (tag || '').toLowerCase(); const base = lower.split('-')[0];
          let m = voices.find(v => (v.lang || '').toLowerCase() === lower); if (m) return m;
          m = voices.find(v => (v.lang || '').toLowerCase().startsWith(base + '-')); if (m) return m;
          m = voices.find(v => (v.lang || '').toLowerCase().startsWith(base)); if (m) return m;
          return voices[0] || null;
        };
        const voices = await getVoicesAsync();
        if (!voices || voices.length === 0) { try { setStatus('No speech voices available', false); } catch {} }
        const best = pickBestVoice(langTag, voices);
        if (best) u.voice = best;
        currentUtterance = u; window.speechSynthesis.speak(u);
      }
    } catch {}
  } catch (err) {
    renderMessage('assistant', `Error: ${err?.message || 'Something went wrong'}`, s.messages.length);
  } finally {
    pendingFiles = [];
    renderAttachments();
    setSending(false);
  }
});

if (clearButton) clearButton.addEventListener('click', () => {
  ensureActiveSession();
  const s = getActive();
  s.messages = []; s.updatedAt = nowISO(); saveSessions();
  renderChat();
});

if (newChatButton) newChatButton.addEventListener('click', () => {
  const s = createSession('New chat'); activeId = s.id; saveActiveId(activeId); renderSessions(); renderChat();
  pendingFiles = []; renderAttachments();
});

function formatMessagesForShare(msgs) {
  return msgs.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
}

if (shareChatBtn) {
  shareChatBtn.addEventListener('click', async () => {
    const s = getActive();
    if (!s || !s.messages.length) { alert('No messages to share.'); return; }
    const text = formatMessagesForShare(s.messages);
    try {
      if (navigator.share) {
        await navigator.share({ title: s.title || 'Chat', text });
      } else {
        await navigator.clipboard.writeText(text);
        alert('Chat copied to clipboard. You can paste it to share.');
      }
    } catch {}
  });
}

// Close any open menus when clicking outside
document.addEventListener('click', (e) => {
  document.querySelectorAll('.menu').forEach(m => {
    if (!m.contains(e.target) && m !== e.target) m.classList.add('hidden');
  });
});

// Mic
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SR) { if (micButton) { micButton.disabled = true; micButton.title = 'Speech recognition not supported in this browser'; setStatus('Mic not supported', false); } }
else if (micButton) {
  try {
    recognition = new SR(); recognition.lang = mapLangPrefToLocale(); recognition.interimResults = false; recognition.continuous = false; recognition.maxAlternatives = 1;
    recognition.onstart = () => { recognizing = true; micButton.classList.add('recording'); micButton.textContent = '●'; setStatus('Listening…'); };
    recognition.onend = () => { recognizing = false; micButton.classList.remove('recording'); micButton.textContent = '🎤'; setStatus('Ready'); };
    recognition.onerror = (ev) => { recognizing = false; micButton.classList.remove('recording'); micButton.textContent = '🎤'; try { setStatus(`Mic error${ev && ev.error ? ': ' + ev.error : ''}`, false); } catch {} };
    recognition.onresult = (e) => {
      try {
        if (!e || !e.results) return;
        let transcript = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const res = e.results[i];
          if (res.isFinal && res[0] && res[0].transcript) transcript += res[0].transcript + ' ';
        }
        transcript = transcript.trim();
        if (transcript) {
          input.value = (input.value ? input.value + ' ' : '') + transcript;
          form.dispatchEvent(new Event('submit'));
        }
      } catch {}
    };
    async function ensureMicPermission() {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return true; // try anyway
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        try { stream.getTracks().forEach(t => t.stop()); } catch {}
        micButton.title = '';
        return true;
      } catch (err) {
        micButton.title = 'Microphone permission denied or blocked';
        try { setStatus('Mic permission blocked. Enable mic and try again.', false); } catch {}
        return false;
      }
    }
    micButton.addEventListener('click', async () => {
      try {
        if (!recognizing) {
          const ok = await ensureMicPermission();
          if (!ok) return;
          recognition.lang = mapLangPrefToLocale();
          recognition.start();
        } else {
          recognition.stop();
        }
      } catch {}
    });
  } catch { micButton.disabled = true; micButton.title = 'Mic init failed'; }
}

// File attachments helpers and UI
function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result || '');
      const base64 = res.includes(',') ? res.split(',')[1] : res;
      resolve({ name: file.name, mimeType: file.type || 'application/octet-stream', dataBase64: base64 });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function isImage(mime) { return /^image\//i.test(mime || ''); }

function renderAttachments() {
  if (!attachmentsEl) return;
  attachmentsEl.innerHTML = '';
  pendingFiles.forEach((f, idx) => {
    const chip = el('div', 'attach-chip');
    if (isImage(f.mimeType)) {
      const img = document.createElement('img');
      img.src = `data:${f.mimeType};base64,${f.dataBase64}`;
      chip.appendChild(img);
    }
    const label = el('span', null, f.name || f.mimeType);
    const rm = el('button', 'attach-remove', '✕');
    rm.addEventListener('click', () => { pendingFiles.splice(idx, 1); renderAttachments(); });
    chip.appendChild(label); chip.appendChild(rm);
    attachmentsEl.appendChild(chip);
  });
}

if (attachBtn && fileInput) {
  attachBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const files = Array.from(fileInput.files || []);
    if (!files.length) return;
    const base64s = await Promise.all(files.map(readFileAsBase64));
    pendingFiles.push(...base64s);
    renderAttachments();
    fileInput.value = '';
  });
}

// Auto-speak preference
if (autoSpeakToggle) {
  try { autoSpeakToggle.checked = localStorage.getItem('mini-gemini-auto-speak') === '1'; } catch {}
  autoSpeakToggle.addEventListener('change', () => {
    try { localStorage.setItem('mini-gemini-auto-speak', autoSpeakToggle.checked ? '1' : '0'); } catch {}
  });
}

// Language preference
if (langSelect) {
  try { langSelect.value = localStorage.getItem('mini-gemini-lang') || 'auto'; } catch {}
  langSelect.addEventListener('change', () => {
    try { localStorage.setItem('mini-gemini-lang', langSelect.value); } catch {}
    try { if (recognition) recognition.lang = mapLangPrefToLocale(langSelect.value); } catch {}
  });
}

// Permissions API hinting for mic state (best-effort)
try {
  if (navigator.permissions && navigator.permissions.query) {
    navigator.permissions.query({ name: 'microphone' }).then((status) => {
      const update = () => {
        if (status.state === 'denied') { micButton && (micButton.title = 'Microphone permission denied'); setStatus('Mic permission denied', false); }
        else if (status.state === 'prompt') { micButton && (micButton.title = 'Click mic and allow access'); }
        else { micButton && (micButton.title = 'Speak'); }
      };
      update();
      status.onchange = update;
    }).catch(() => {});
  }
} catch {}

// Audio unlock to satisfy autoplay policies for speech synthesis
function unlockAudioIfNeeded() {
  if (audioUnlocked) return;
  try { if (window.speechSynthesis) { window.speechSynthesis.resume(); } } catch {}
  try {
    if (window.AudioContext || window.webkitAudioContext) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      if (ctx.state === 'suspended') { ctx.resume().catch(() => {}); }
      // Create a short silent buffer to ensure a user-gesture playback path
      const buffer = ctx.createBuffer(1, 1, 22050);
      const src = ctx.createBufferSource();
      src.buffer = buffer; src.connect(ctx.destination); src.start(0);
      setTimeout(() => { try { src.disconnect(); ctx.close(); } catch {} }, 50);
    }
  } catch {}
  audioUnlocked = true;
}

['click', 'keydown', 'touchstart'].forEach((ev) => {
  window.addEventListener(ev, unlockAudioIfNeeded, { once: true, passive: true });
});

// Bootstrap
sessions = loadSessions();
migrateLegacy();
activeId = loadActiveId() || activeId;
ensureActiveSession();
renderSessions();
renderChat();
pingHealth();
setInterval(pingHealth, 15000);


// TTS test button
if (ttsTestBtn) {
  ttsTestBtn.addEventListener('click', async () => {
    try {
      if (!window.speechSynthesis) { setStatus('Speech not supported', false); return; }
      unlockAudioIfNeeded();
      const text = 'Hello! This is a voice test.';
      const langTag = mapLangPrefToLocale();
      try { window.speechSynthesis.cancel(); window.speechSynthesis.resume(); } catch {}
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1; u.pitch = 1; u.lang = langTag;
      u.onend = () => { try { setStatus('Ready'); } catch {} };
      u.onerror = () => { try { setStatus('Speech error', false); } catch {} };
      const getVoicesAsync = () => {
        const v = window.speechSynthesis.getVoices();
        if (v && v.length) return Promise.resolve(v);
        return new Promise((resolve) => {
          let resolved = false;
          const done = () => { if (!resolved) { resolved = true; resolve(window.speechSynthesis.getVoices() || []); } };
          window.speechSynthesis.onvoiceschanged = () => { done(); window.speechSynthesis.onvoiceschanged = null; };
          setTimeout(done, 800);
        });
      };
      const pickBestVoice = (tag, voices) => {
        if (!voices || !voices.length) return null; const lower = (tag || '').toLowerCase(); const base = lower.split('-')[0];
        let m = voices.find(v => (v.lang || '').toLowerCase() === lower); if (m) return m;
        m = voices.find(v => (v.lang || '').toLowerCase().startsWith(base + '-')); if (m) return m;
        m = voices.find(v => (v.lang || '').toLowerCase().startsWith(base)); if (m) return m;
        return voices[0] || null;
      };
      const voices = await getVoicesAsync();
      if (!voices || voices.length === 0) { setStatus('No speech voices available', false); return; }
      const best = pickBestVoice(langTag, voices);
      if (best) u.voice = best;
      setStatus('Speaking…');
      currentUtterance = u;
      window.speechSynthesis.speak(u);
    } catch {}
  });
}
